

-- inserting all sales data into one table
INSERT INTO [Practice].[dbo].[sales]
SELECT * FROM [Practice].[dbo].[sales_2016_r12_]

INSERT INTO [Practice].[dbo].[sales]
SELECT * FROM [Practice].[dbo].[sales_2016_r34]

-- Enrich Data
SELECT 
	 s.[identifier]
    ,s.[Network]
    ,s.[Region]
    ,s.[Date]
    ,s.[Product]
    ,s.[Amount]
	,r.RegionDescription
FROM 
	[Practice].[dbo].[sales] as s
	INNER JOIN [Practice].[dbo].[region_2016] as r
		ON s.Region = r.Region



-- SUM total Sales per Region and Network
-- COUNT total sales
SELECT 
    s.[Network]
    ,s.[Region]
	,SUM(s.[Amount]) as SalesAmount
	,COUNT(s.[Amount]) as SalesCount
FROM 
	[Practice].[dbo].[sales] as s
	INNER JOIN [Practice].[dbo].[region_2016] as r
		ON s.Region = r.Region
GROUP BY
	s.[Network]
    ,s.[Region]
	,r.RegionDescription



--Insert into Output table
INSERT INTO practice.dbo.[output] ([Network_Region],SalesAmount,SalesCount)
--Network
SELECT 
    s.[Network]
	,SUM(s.[Amount]) as SalesAmount
	,COUNT(s.[Amount]) as SalesCount
FROM 
	[Practice].[dbo].[sales] as s
	INNER JOIN [Practice].[dbo].[region_2016] as r
		ON s.Region = r.Region
GROUP BY
	s.[Network]

INSERT INTO practice.dbo.[output] ([Network_Region],SalesAmount,SalesCount)
--Region
SELECT 
    s.[Region]
	,SUM(s.[Amount]) as SalesAmount
	,COUNT(s.[Amount]) as SalesCount
FROM 
	[Practice].[dbo].[sales] as s
	INNER JOIN [Practice].[dbo].[region_2016] as r
		ON s.Region = r.Region
GROUP BY
	s.[Region]


-- move data to archive database
INSERT INTO [Practice].[dbo].[archive]
SELECT * FROM [Practice].[dbo].[sales]
TRUNCATE TABLE [Practice].[dbo].[sales]